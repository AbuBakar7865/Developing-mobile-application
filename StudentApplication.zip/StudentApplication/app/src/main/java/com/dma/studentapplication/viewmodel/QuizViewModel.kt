package com.dma.studentapplication.viewmodel
import android.app.Application
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import com.dma.studentapplication.model.Question
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class QuizViewModel(application: Application) : AndroidViewModel(application) {

    // Using State objects so the UI "observes" changes automatically
    val currentQuestions = mutableStateListOf<Question>()
    val currentIndex = mutableStateOf(0)
    val score = mutableStateOf(0)
    val isQuizFinished = mutableStateOf(false)
    val userAnswers = mutableStateListOf<Int?>()

    fun loadQuestions(fileName: String) {
        try {
            val context = getApplication<Application>()
            val jsonString = context.assets.open(fileName).bufferedReader().use { it.readText() }
            val listType = object : TypeToken<List<Question>>() {}.type
            val loadedData: List<Question> = Gson().fromJson(jsonString, listType)
            val randomTen = loadedData.shuffled().take(10)

            userAnswers.clear()
            repeat(10) { userAnswers.add(null) }

            currentQuestions.clear()
            currentQuestions.addAll(randomTen)


            currentIndex.value = 0
            score.value = 0
            isQuizFinished.value = false

        } catch (e: Exception) {
            currentQuestions.clear()
            currentQuestions.add(com.dma.studentapplication.model.Question(
                "Technical Error: ${e.message}", // This will tell us the EXACT problem
                listOf("Retry"),
                0
            ))
        }
    }

    fun submitAnswer(selectedIndex: Int) {
        userAnswers[currentIndex.value] = selectedIndex
        if (selectedIndex == currentQuestions[currentIndex.value].correctAnswerIndex) {
            score.value++
        }

        if (currentIndex.value < currentQuestions.size - 1) {
            currentIndex.value++
        } else {
            isQuizFinished.value = true
        }
    }
}