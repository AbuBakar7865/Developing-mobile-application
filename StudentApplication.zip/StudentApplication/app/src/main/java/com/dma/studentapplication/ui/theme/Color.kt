package com.dma.studentapplication.ui.theme

import androidx.compose.ui.graphics.Color

val OceanBlue = Color(0xFF0056D2)

val DeepTeal = Color(0xFF00838F)

val SkyBlue = Color(0xFFE3F2FD)

val Midnight = Color(0xFF1A1C1E)
