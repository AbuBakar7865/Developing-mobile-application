package com.dma.studentapplication

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.rememberNavController
import com.dma.studentapplication.ui.QuizNavHost
import com.dma.studentapplication.ui.theme.StudentApplicationTheme
import com.dma.studentapplication.viewmodel.QuizViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            StudentApplicationTheme {
                val navController = rememberNavController()
                val quizViewModel: QuizViewModel = viewModel()


                QuizNavHost(navController = navController, viewModel = quizViewModel)
            }
        }
    }
}


@Preview(showBackground = true, showSystemUi = true)
@Composable
fun StudentApplicationPreview() {
    StudentApplicationTheme {

        val navController = rememberNavController()
        val quizViewModel: QuizViewModel = viewModel()

        QuizNavHost(navController = navController, viewModel = quizViewModel)
    }
}
