package com.dma.studentapplication.data
import android.content.Context
import com.dma.studentapplication.model.QuizData
import com.google.gson.Gson

object AssetLoader {
    fun loadQuizData(context: Context, fileName: String): QuizData? {
        return try {
            // This line looks into the 'assets' folder you showed in image_0c555f.png
            val jsonString = context.assets.open(fileName).bufferedReader().use { it.readText() }

            // This line 'serializes' the text into our Kotlin data classes
            Gson().fromJson(jsonString, QuizData::class.java)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
