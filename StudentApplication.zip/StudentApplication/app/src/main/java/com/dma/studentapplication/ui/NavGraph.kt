package com.dma.studentapplication.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.dma.studentapplication.viewmodel.QuizViewModel

@Composable
fun QuizNavHost(navController: NavHostController, viewModel: QuizViewModel) {
    NavHost(
        navController = navController,
        startDestination = "topics"
    ) {
        composable(route = "topics") {
            TopicSelectionScreen(
                viewModel = viewModel,
                onTopicSelected = { topicFile ->
                    viewModel.loadQuestions(topicFile)
                    navController.navigate("quiz_screen")
                }
            )
        }

        composable(route = "quiz_screen") {
            QuizScreen(
                viewModel = viewModel,
                onQuizFinished = {
                    navController.navigate("results")
                }
            )
        }

        composable(route = "results") {
            ResultsScreen(
                viewModel = viewModel,
                onRestart = {
                    navController.navigate("topics") {
                        popUpTo("topics") { inclusive = true }
                    }
                }
            )
        }
    }
}