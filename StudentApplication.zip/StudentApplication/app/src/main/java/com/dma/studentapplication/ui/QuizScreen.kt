package com.dma.studentapplication.ui

import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.MutableState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.dma.studentapplication.viewmodel.QuizViewModel

@Composable
fun QuizScreen(viewModel: QuizViewModel, onQuizFinished: () -> Unit) {

    val currentIndex = viewModel.currentIndex.value
    val questions = viewModel.currentQuestions
    if (questions.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator()
        }
        return
    }
    val currentQuestion = questions.getOrNull(currentIndex)
    val selectedOption: MutableState<Int?> = remember { mutableStateOf(null) }
    // -----------------------------------------------------

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        // Progress Header
        Text(
            text = "Question ${currentIndex + 1} of ${questions.size}",
            style = MaterialTheme.typography.labelLarge,
            color = Color(0xFF0056D2)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Only draw if the question exists
        currentQuestion?.let { question ->
            Text(
                text = question.questionText,
                style = MaterialTheme.typography.headlineSmall,
                color = Color.Black
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Options List
            question.options.forEachIndexed { index, option ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .selectable(
                            selected = (selectedOption.value == index),
                            onClick = { selectedOption.value = index }
                        )
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = (selectedOption.value == index),
                        onClick = { selectedOption.value = index },
                        colors = RadioButtonDefaults.colors(selectedColor = Color(0xFF00838F))
                    )
                    Text(
                        text = option,
                        modifier = Modifier.padding(start = 8.dp),
                        color = Color.Black
                    )
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            // Action Button
            Button(
                onClick = {
                    selectedOption.value?.let { choice ->
                        viewModel.submitAnswer(choice)
                        selectedOption.value = null

                        if (viewModel.isQuizFinished.value) {
                            onQuizFinished()
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                enabled = selectedOption.value != null,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0056D2))
            ) {
                // If it's the last question, show FINISH, otherwise NEXT
                Text(text = if (currentIndex < questions.size - 1) "NEXT" else "FINISH")
            }
        }
    }
}
