package com.dma.studentapplication.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.dma.studentapplication.viewmodel.QuizViewModel

@Composable
fun TopicSelectionScreen(
    viewModel: QuizViewModel,
    onTopicSelected: (String) -> Unit
) {
    val topics = listOf(
        "Activity & Intent" to "activity_intent.json",
        "Jetpack Compose" to "jetpack_compose.json",
        "Kotlin" to "kotlin.json",
        "ViewModel & Room" to "viewmodel_room.json"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = "ANDROID TOPICS",
            style = MaterialTheme.typography.headlineLarge.copy(
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF0056D2)
            ),
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Text(
            text = "Select a category to begin your assessment",
            style = MaterialTheme.typography.bodyLarge,
            color = Color.Gray,
            modifier = Modifier.padding(bottom = 32.dp)
        )

        topics.forEach { (title, fileName) ->
            Button(
                onClick = {
                    viewModel.loadQuestions(fileName)
                    onTopicSelected(fileName)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .height(64.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF00838F)
                ),
                shape = MaterialTheme.shapes.large,
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White
                )
            }
        }
    }
}