package com.dma.studentapplication.model

data class QuizData(
    val questions: List<Question>
)