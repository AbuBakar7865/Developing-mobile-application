package com.dma.studentapplication.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dma.studentapplication.viewmodel.QuizViewModel
import com.dma.studentapplication.model.Question

@Composable
fun ResultsScreen(viewModel: QuizViewModel, onRestart: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "Quiz Completed!", fontSize = 24.sp, fontWeight = FontWeight.Bold)

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Your Score: ${viewModel.score.value} / 10",
            fontSize = 32.sp,
            color = Color(0xFF00838F),
            fontWeight = FontWeight.ExtraBold
        )
        Spacer(modifier = Modifier.height(24.dp))

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            itemsIndexed(viewModel.currentQuestions) { index, question ->
                ResultCard(
                    question = question,
                    userChoice = viewModel.userAnswers[index],
                    index = index
                )
            }
        }

        Spacer(modifier = Modifier.height(48.dp))

        Button(
            onClick = onRestart,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0056D2))
        ) {
            Text("TRY ANOTHER TOPIC")
        }
    }
}
@Composable
fun ResultCard(
    question: Question,
    userChoice: Int?,
    index: Int
) {
    val isCorrect = userChoice == question.correctAnswerIndex


    val backgroundColor = if (isCorrect) Color(0xFFC8E6C9) else Color(0xFFEF9A9A)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = backgroundColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = "${index + 1}. ${question.questionText}",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.bodyLarge
            )

            Spacer(modifier = Modifier.height(4.dp))


            Text(
                text = "Correct: ${question.options[question.correctAnswerIndex]}",
                style = MaterialTheme.typography.bodyMedium
            )


            if (!isCorrect) {
                val chosenText = if (userChoice != null) question.options[userChoice] else "Skipped"
                Text(
                    text = "Your Answer: $chosenText",
                    color = Color(0xFFB00020),
                    fontWeight = FontWeight.Medium,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}